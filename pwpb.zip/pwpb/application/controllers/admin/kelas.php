<?php

class Kelas extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model("kelas_model");
        $this->load->library('form_validation');
        $this->load->helper('rupiah_helper');
    }

    public function index()
    {
        if ($this->session->userdata('akses') == 'admin' || $this->session->userdata('akses') == 'petugas') {

            $data['GetKelas'] = $this->kelas_model->getAll();

            $this->load->view('admin/kelas/v_kelas', $data);
        } else {
            echo "Anda tidak berhak mengakses halaman ini";
        }
    }

    function add()
    {
        if ($this->session->userdata('akses') == 'admin' || $this->session->userdata('akses') == 'petugas') {
            $AddKelas = $this->kelas_model;
            $validation = $this->form_validation;
            $validation->set_rules($AddKelas->rules());

            if ($validation->run()) {
                $AddKelas->save();
                $this->session->set_flashdata('success', 'Berhasil disimpan');
            }


            $this->load->model("keahlian_model");
            $data['GetKK'] = $this->keahlian_model->getAll();

            $this->load->view('admin/kelas/v_add_kelas', $data);
        } else {
            echo "Anda tidak berhak mengakses halaman ini";
        }
    }

    function edit($id_kelas = null)
    {
        if ($this->session->userdata('akses') == 'admin' || $this->session->userdata('akses') == 'petugas') {
            if (!isset($id_kelas)) redirect('admin/kelas');

            $EditKelas = $this->kelas_model;
            $validation = $this->form_validation;
            $validation->set_rules($EditKelas->rules());

            if ($validation->run()) {
                $EditKelas->update();
                $this->session->set_flashdata('success', 'Berhasil disimpan');
            }


            $data['GetKelas'] = $EditKelas->getById($id_kelas);
            $this->load->model("keahlian_model");
            $data['GetKK'] = $this->keahlian_model->getAll();

            if (!$data['GetKelas']) show_404();

            $this->load->view('admin/kelas/v_edit_kelas', $data);
        } else {
            echo "Anda tidak berhak mengakses halaman ini";
        }
    }

    function delete($id_kelas = null)
    {
        if (!isset($id_kelas)) show_404();

        if ($this->kelas_model->delete($id_kelas)) {
            $this->session->set_flashdata('danger', 'Berhasil dihapus');
            redirect(site_url('admin/kelas'));
        }
    }
}
