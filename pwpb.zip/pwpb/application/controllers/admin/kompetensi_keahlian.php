<?php

class Kompetensi_keahlian extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model("keahlian_model");
		$this->load->library('form_validation');
	}

	public function index()
	{
		if ($this->session->userdata('akses') == 'admin' || $this->session->userdata('akses') == 'petugas') {
			$data['GetKK'] = $this->keahlian_model->getAll();
			$this->load->view('admin/kk/v_kk', $data);
		} else {
			echo "Anda tidak berhak mengakses halaman ini";
		}
	}

	function add()
	{
		if ($this->session->userdata('akses') == 'admin' || $this->session->userdata('akses') == 'petugas') {
			$AddKK = $this->keahlian_model;
			$validation = $this->form_validation;
			$validation->set_rules($AddKK->rules());

			if ($validation->run()) {
				$AddKK->save();
				$this->session->set_flashdata('success', 'Berhasil disimpan');
			}




			$this->load->view('admin/kk/v_add_kk');
		} else {
			echo "Anda tidak berhak mengakses halaman ini";
		}
	}

	function edit($id_kk = null)
	{
		if ($this->session->userdata('akses') == 'admin' || $this->session->userdata('akses') == 'petugas') {
			if (!isset($id_kk)) redirect('admin/kompetensi_keahlian');

			$EditKK = $this->keahlian_model;
			$validation = $this->form_validation;
			$validation->set_rules($EditKK->rules());

			if ($validation->run()) {
				$EditKK->update();
				$this->session->set_flashdata('success', 'Berhasil disimpan');
			}

			$data['GetKK'] = $EditKK->getById($id_kk);

			if (!$data['GetKK']) show_404();

			$this->load->view('admin/kk/v_edit_kk', $data);
		} else {
			echo "Anda tidak berhak mengakses halaman ini";
		}
	}

	function delete($id_kk = null)
	{
		if (!isset($id_kk)) show_404();

		if ($this->keahlian_model->delete($id_kk)) {
			$this->session->set_flashdata('danger', 'Berhasil dihapus');
			redirect(site_url('admin/kompetensi_keahlian'));
		}
	}
}