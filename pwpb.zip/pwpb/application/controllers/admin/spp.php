<?php

class Spp extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model("spp_model");
        $this->load->library('form_validation');
        $this->load->helper('rupiah_helper');
    }

    public function index()
    {
        if ($this->session->userdata('akses') == 'admin' || $this->session->userdata('akses') == 'petugas') {
            $data['GetSpp'] = $this->spp_model->getAll();

            $this->load->view('admin/spp/v_spp', $data);
        } else {
            echo "Anda tidak berhak mengakses halaman ini";
        }
    }

    function add()
    {
        if ($this->session->userdata('akses') == 'admin' || $this->session->userdata('akses') == 'petugas') {
            $AddSpp = $this->spp_model;
            $validation = $this->form_validation;
            $validation->set_rules($AddSpp->rules());

            if ($validation->run()) {
                $AddSpp->save();
                $this->session->set_flashdata('success', 'Berhasil disimpan');
            }



            $this->load->view('admin/spp/v_add_spp');
        } else {
            echo "Anda tidak berhak mengakses halaman ini";
        }
    }

    function edit($id_spp = null)
    {
        if (!isset($id_spp)) redirect('admin/spp');

        $EditSpp = $this->spp_model;
        $validation = $this->form_validation;
        $validation->set_rules($EditSpp->rules());

        if ($validation->run()) {
            $EditSpp->update();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }

        $data['title'] = "Edit SPP";

        $data['GetSpp'] = $EditSpp->getById($id_spp);

        if (!$data['GetSpp']) show_404();

        $this->load->view('admin/spp/v_edit_spp', $data);
    }

    function delete($id_spp = null)
    {
        if (!isset($id_spp)) show_404();

        if ($this->spp_model->delete($id_spp)) {
            $this->session->set_flashdata('danger', 'Berhasil dihapus');
            redirect(site_url('admin/spp'));
        }
    }

    
}
