<?php return function ($fontDir, $rootDir) {
return array (
  'sans-serif' => array(
    'normal' => $fontDir . '/Helvetica',
    'bold' => $fontDir . '/Helvetica-Bold',
    'italic' => $fontDir . '/Helvetica-Oblique',
    'bold_italic' => $fontDir . '/Helvetica-BoldOblique',
  ),
  'times' => array(
    'normal' => $fontDir . '/Times-Roman',
    'bold' => $fontDir . '/Times-Bold',
    'italic' => $fontDir . '/Times-Italic',
    'bold_italic' => $fontDir . '/Times-BoldItalic',
  ),
  'times-roman' => array(
    'normal' => $fontDir . '/Times-Roman',
    'bold' => $fontDir . '/Times-Bold',
    'italic' => $fontDir . '/Times-Italic',
    'bold_italic' => $fontDir . '/Times-BoldItalic',
  ),
  'courier' => array(
    'normal' => $fontDir . '/Courier',
    'bold' => $fontDir . '/Courier-Bold',
    'italic' => $fontDir . '/Courier-Oblique',
    'bold_italic' => $fontDir . '/Courier-BoldOblique',
  ),
  'helvetica' => array(
    'normal' => $fontDir . '/Helvetica',
    'bold' => $fontDir . '/Helvetica-Bold',
    'italic' => $fontDir . '/Helvetica-Oblique',
    'bold_italic' => $fontDir . '/Helvetica-BoldOblique',
  ),
  'zapfdingbats' => array(
    'normal' => $fontDir . '/ZapfDingbats',
    'bold' => $fontDir . '/ZapfDingbats',
    'italic' => $fontDir . '/ZapfDingbats',
    'bold_italic' => $fontDir . '/ZapfDingbats',
  ),
  'symbol' => array(
    'normal' => $fontDir . '/Symbol',
    'bold' => $fontDir . '/Symbol',
    'italic' => $fontDir . '/Symbol',
    'bold_italic' => $fontDir . '/Symbol',
  ),
  'serif' => array(
    'normal' => $fontDir . '/Times-Roman',
    'bold' => $fontDir . '/Times-Bold',
    'italic' => $fontDir . '/Times-Italic',
    'bold_italic' => $fontDir . '/Times-BoldItalic',
  ),
  'monospace' => array(
    'normal' => $fontDir . '/Courier',
    'bold' => $fontDir . '/Courier-Bold',
    'italic' => $fontDir . '/Courier-Oblique',
    'bold_italic' => $fontDir . '/Courier-BoldOblique',
  ),
  'fixed' => array(
    'normal' => $fontDir . '/Courier',
    'bold' => $fontDir . '/Courier-Bold',
    'italic' => $fontDir . '/Courier-Oblique',
    'bold_italic' => $fontDir . '/Courier-BoldOblique',
  ),
  'dejavu sans' => array(
    'bold' => $fontDir . '/DejaVuSans-Bold',
    'bold_italic' => $fontDir . '/DejaVuSans-BoldOblique',
    'italic' => $fontDir . '/DejaVuSans-Oblique',
    'normal' => $fontDir . '/DejaVuSans',
  ),
  'dejavu sans mono' => array(
    'bold' => $fontDir . '/DejaVuSansMono-Bold',
    'bold_italic' => $fontDir . '/DejaVuSansMono-BoldOblique',
    'italic' => $fontDir . '/DejaVuSansMono-Oblique',
    'normal' => $fontDir . '/DejaVuSansMono',
  ),
  'dejavu serif' => array(
    'bold' => $fontDir . '/DejaVuSerif-Bold',
    'bold_italic' => $fontDir . '/DejaVuSerif-BoldItalic',
    'italic' => $fontDir . '/DejaVuSerif-Italic',
    'normal' => $fontDir . '/DejaVuSerif',
  ),
  'poppins' => array(
    '100' => $fontDir . '/poppins_100_104551a0905c56901764487164dd049b',
    '200' => $fontDir . '/poppins_200_218d0b56c375084b9a741ea4d56316b8',
    '200_italic' => $fontDir . '/poppins_200_italic_3e7a02db866c4ed3cf20abcd9c39f739',
    '100_italic' => $fontDir . '/poppins_100_italic_33428e28d1891b1c3730500b92311ce1',
    '300' => $fontDir . '/poppins_300_838101dc0052c6b4c5c6369bf030ce16',
    '300_italic' => $fontDir . '/poppins_300_italic_fbf772dfa79850d54e8cdd76479a8e0c',
    'normal' => $fontDir . '/poppins_normal_bb3a11d9348a20014deb3d60ce21b5f5',
    'italic' => $fontDir . '/poppins_italic_38d3d616e96074529f56f863016955a1',
    '500' => $fontDir . '/poppins_500_fc758c485c4d8e8cd03bc18fb7035400',
    '500_italic' => $fontDir . '/poppins_500_italic_7416559318d561fa350a488cad460559',
    '600' => $fontDir . '/poppins_600_8b830bc87bde1964ff1f19e424f047f9',
    '600_italic' => $fontDir . '/poppins_600_italic_76ed3d1bf156380e9239aad0e2a374b6',
    'bold' => $fontDir . '/poppins_bold_3427e8ad8b6cabb34065a77af71b2d0f',
    'bold_italic' => $fontDir . '/poppins_bold_italic_901a2f1a3c271fc1b69b0212c9b9e953',
    '800' => $fontDir . '/poppins_800_d1f3278d982a9cc35fb8e66790adef6a',
    '800_italic' => $fontDir . '/poppins_800_italic_efacb35e396e1797ae9ff4d66b88fef6',
    '900' => $fontDir . '/poppins_900_b4093258a1d2222cf81a91565302db34',
    '900_italic' => $fontDir . '/poppins_900_italic_f7ead950ea3589f6a2661d7fea48e137',
  ),
  'fontawesome' => array(
    'normal' => $fontDir . '/fontawesome_normal_3978c3784f44e898199d57bb537a34c4',
  ),
  'font awesome 5 brands' => array(
    'normal' => $fontDir . '/font_awesome_5_brands_normal_6b898e2c5cc213c4404811c323fdcab6',
  ),
  'font awesome 5 free' => array(
    'normal' => $fontDir . '/font_awesome_5_free_normal_09a636486ad6e3e7e715ee5a0373f2ab',
    '900' => $fontDir . '/font_awesome_5_free_900_f6c1d66ca0f6a9c230936770c324b606',
  ),
  'material-design-iconic-font' => array(
    'normal' => $fontDir . '/material_design_iconic_font_normal_5d92c11e7e787bc2eabe7db96690689c',
  ),
  'font awesome\\ 5 brands' => array(
    'normal' => $fontDir . '/font_awesome__5_brands_normal_485ee3e7eecd868dfd21968f2fe9b896',
  ),
  'font awesome\\ 5 free' => array(
    'normal' => $fontDir . '/font_awesome__5_free_normal_5d9e986f0f5bdfef77f360e6d64696c0',
    '900' => $fontDir . '/font_awesome__5_free_900_f3ca5e9ba2341aea5dcd1c13de65ea1a',
  ),
);
}; ?>