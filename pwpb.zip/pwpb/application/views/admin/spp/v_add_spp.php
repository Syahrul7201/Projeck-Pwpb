<!DOCTYPE html>
<html lang="en">

<head>
<?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php $this->load->view('admin/_partials/header_mobile.php') ?>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <?php $this->load->view('admin/_partials/sidebar.php') ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php $this->load->view('admin/_partials/header_desktop.php') ?>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT WRAPPER-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                    <?php $this->load->view('admin/_partials/breadcrump.php') ?>

                    <!-- ALERT CONTENT -->
                    <?php $this->load->view('admin/_partials/alert.php') ?>
                    
                    <!-- MAIN CONTENT -->


                  <div class="card border-info">
                      <div class="card-header">
                        <a class="btn-sm btn btn-warning" href="<?php echo site_url('admin/spp') ?>"><i class="fas fa-plus"> TAMBAH DATA</i></a>
                      </div>
                      <form class="mx-1 my-1" action="" method="POST">
                        <div class="input-group mb-3">
                        <span class="input-group-text rounded-0 col-sm-2" id="basic-addon1">Tahun Ajaran</span>
                        <input name="tahun" type="text" class="form-control" placeholder="Tahun" aria-label="Username" aria-describedby="basic-addon1">
                        </div>
                        <div class="input-group mb-3">
                        <span class="input-group-text rounded-0 col-sm-2" id="basic-addon1">Nominal</span>
                        <input name="nominal" type="text" class="form-control" placeholder="Nominal" aria-label="Username" aria-describedby="basic-addon1">
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        
                      </form>
                      </div>
                      </div>
                  </div>
                  </div>
              </div>
            </div>


            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    

</body>
<?php $this->load->view('admin/_partials/footer.php') ?>
<?php $this->load->view('admin/_partials/modal.php') ?>
</html>
<!-- end document-->
