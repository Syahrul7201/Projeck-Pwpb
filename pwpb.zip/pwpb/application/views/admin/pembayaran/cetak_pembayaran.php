<!DOCTYPE html>
<html lang="en">

<head>
<?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body>
    <div class="text-center">
        <h2>LAPORAN PDF SISWA</h2>
    </div>
    <table class="table table-hover text-center"style="font-size: 10;">
                      <thead>
                        <tr class="text-primary">
                          <th scope="col" style="width:50px">No</th>
                          <th scope="col">Nama Petugas</th>
                          <th scope="col">NISN</th>
                          <th scope="col">Nama Siswa</th>
                          <th scope="col">Tanggal diBayar</th>
                          <th scope="col">Bulan diBayar</th>
                          <th scope="col">Tahun diBayar</th>
                          <th scope="col">Nominal</th>
                          <th scope="col">Jumlah Bayar</th>
                        </tr>
                      </thead>
        <tbody>
        <?php
            $no = 1;
            foreach ($pem as $pem) : ?>
                <tr>
                    <td>
                        <?php echo $no++; ?>
                    </td>
                    <td>
                        <?php echo $pem->nama_petugas ?>
                    </td>
                    <td>
                        <?php echo $pem->nisn ?>
                    </td>
                    <td style="font-size: 10;">
                        <?php echo $pem->nama ?>
                    </td>
                    <td>
                        <?php echo $pem->tgl_bayar ?>
                    </td>
                    <td>
                        <?php echo $pem->bulan_bayar ?>
                    </td>
                    <td>
                        <?php echo $pem->tahun_bayar ?>
                    </td>
                    <td>
                        <?php echo rupiah($pem->nominal) ?>
                    </td>
                    <td>
                        <?php echo rupiah($pem->jumlah_bayar) ?>
                    </td>

                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>