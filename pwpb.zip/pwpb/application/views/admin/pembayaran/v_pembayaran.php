<!DOCTYPE html>
<html lang="en">

<head>
<?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php $this->load->view('admin/_partials/header_mobile.php') ?>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <?php $this->load->view('admin/_partials/sidebar.php') ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php $this->load->view('admin/_partials/header_desktop.php') ?>
            <!-- HEADER DESKTOP-->

           <!-- MAIN CONTENT WRAPPER-->
           <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                    <?php $this->load->view('admin/_partials/breadcrump.php') ?>

                    <!-- ALERT CONTENT -->
                    <?php $this->load->view('admin/_partials/alert.php') ?>
                    
                    <!-- MAIN CONTENT -->


                    <div class="card border-info mb-5">
                      <div class="card-header d-flex justify-content-end">
                        <a class="btn-sm btn btn-outline-primary" href="<?php echo site_url('admin/pembayaran/add') ?>"><i class="fas fa-plus"> TAMBAH DATA</i></a>
                        <a class="btn btn-sm btn-outline-primary mx-1" href="<?php echo site_url('admin/pembayaran/cetak') ?>"><i class="fas fa-print"> CETAK DATA</i></a>
                      </div>
                      <table class="table table-hover text-center mb-5" id="asd">
                      <thead>
                        <tr class="text-primary">
                          <th scope="col" style="width:50px">No</th>
                          <th scope="col">Nama Petugas</th>
                          <th scope="col">NISN</th>
                          <th scope="col">Tanggal Pembayaran</th>
                          <th scope="col">Bulan Bayar</th>
                          <th scope="col">Tahun Bayar</th>
                          <th scope="col">Nominal</th>
                          <th scope="col">Jumlah Bayar</th>
                          <th scope="col" style="width:100px">Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          if (!empty($GetPembayaran)) {
                            $i = 1;
                          foreach ($GetPembayaran as $GetR) {
                        ?>
                        <tr>
                          <td>
                            <?php
                              echo $i;
                              $i++;
                            ?>
                          </td>
                          <td><?php echo $GetR->nama_petugas; ?></td>
                          <td><?php echo $GetR->nisn; ?></td>
                          <td><?php echo $GetR->tgl_bayar; ?></td>
                          <td><?php echo $GetR->bulan_bayar; ?></td>
                          <td><?php echo $GetR->tahun_bayar; ?></td>
                          <td><?php echo rupiah($GetR->nominal); ?></td>
                          <td><?php echo rupiah($GetR->jumlah_bayar); ?></td>
                          <td class="text-center">
                            <a class="btn btn-sm btn-warning" href="<?php echo site_url('admin/pembayaran/edit/') . $GetR->id_pembayaran ?>">
                              <i class="fa fa-pen" aria-hidden="true"></i>
                            </a>
                            <a onclick="deleteConfirm('<?php echo site_url('admin/pembayaran/delete/' . $GetR->id_pembayaran) ?>')" href="#!" class="btn btn-sm btn-danger">
                              <i class="fas fa-trash"></i>
                            </a>
                          </td>

                        </tr>
                          <?php } } ?>
                      </tbody>
                    </table>
                      </div>
                      </div>
                  </div>
                  </div>
              </div>
            </div>


            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>
    

    

</body>
<?php $this->load->view('admin/_partials/footer.php') ?>
<?php $this->load->view('admin/_partials/modal.php') ?>
</html>
<!-- end document-->