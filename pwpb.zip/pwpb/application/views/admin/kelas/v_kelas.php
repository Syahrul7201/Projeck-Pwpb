<!DOCTYPE html>
<html lang="en">

<head>
<?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php $this->load->view('admin/_partials/header_mobile.php') ?>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <?php $this->load->view('admin/_partials/sidebar.php') ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php $this->load->view('admin/_partials/header_desktop.php') ?>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT WRAPPER-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                    <?php $this->load->view('admin/_partials/breadcrump.php') ?>

                    <!-- ALERT CONTENT -->
                    <?php $this->load->view('admin/_partials/alert.php') ?>
                    
                    <!-- MAIN CONTENT -->


                    <div class="card border-info">
                      <div class="card-header d-flex justify-content-end">
                        <a class="btn-sm btn btn-outline-primary" href="<?php echo site_url('admin/kelas/add') ?>"><i class="fas fa-plus"> TAMBAH DATA</i></a>
                        <a class="btn btn-sm btn-outline-primary mx-1" href="<?php echo site_url('admin/kelas/cetak') ?>"><i class="fas fa-print"> CETAK DATA</i></a>
                      </div>
                    <table class="table table-hover text-center mb-5" id="asd">
                      <thead>
                        <tr class="text-primary">
                          <th scope="col" style="width:50px">No</th>
                          <th scope="col">Nama kelas</th>
                          <th scope="col">Jurusan</th>
                          <th scope="col" style="width:100px">Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          if (!empty($GetKelas)) {
                            $i = 1;
                          foreach ($GetKelas as $GetS) {
                        ?>
                        <tr>
                          <td>
                            <?php
                              echo $i;
                              $i++;
                            ?>
                          </td>
                          <td><?php echo $GetS->nama_kelas; ?></td>
                          <td><?php echo $GetS->nama_kk; ?></td>
                          <td class="text-center">
                            <a class="btn btn-sm btn-warning" href="<?php echo site_url('admin/kelas/edit/') . $GetS->id_kelas ?>">
                              <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                            </a>
                            <a onclick="deleteConfirm('<?php echo site_url('admin/kelas/delete/' . $GetS->id_kelas) ?>')" href="#!" class="btn btn-sm btn-danger">
                              <i class="fas fa-trash"></i>
                            </a>
                          </td>

                        </tr>
                          <?php } } ?>
                      </tbody>
                    </table>
                      </div>
                      </div>
                  </div>
                  </div>
              </div>
            </div>


            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    

</body>
<?php $this->load->view('admin/_partials/footer.php') ?>
<?php $this->load->view('admin/_partials/modal.php') ?>
</html>
<!-- end document-->
