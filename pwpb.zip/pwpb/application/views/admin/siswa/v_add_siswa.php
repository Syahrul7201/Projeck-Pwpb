<!DOCTYPE html>
<html lang="en">

<head>
<?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php $this->load->view('admin/_partials/header_mobile.php') ?>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <?php $this->load->view('admin/_partials/sidebar.php') ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php $this->load->view('admin/_partials/header_desktop.php') ?>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT WRAPPER-->
            <div class="main-content mb-5">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                    <?php $this->load->view('admin/_partials/breadcrump.php') ?>

                    <!-- ALERT CONTENT -->
                    <?php $this->load->view('admin/_partials/alert.php') ?>
                    
                    <!-- MAIN CONTENT -->


                  <div class="card border-info">
                      <div class="card-header">
                        <a class="btn-sm btn btn-warning" href="<?php echo site_url('admin/siswa') ?>">KEMBALI</i></a>
                      </div>
                      <form class="mx-1 my-1" action="" method="POST">
                        <div class="input-group mb-3">
                            <span class="input-group-text rounded-0 col-sm-2" id="basic-addon1">Nisn</span>
                            <input name="nisn" type="text" class="form-control" placeholder="Nisn" aria-label="Username" aria-describedby="basic-addon1">
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text rounded-0 col-sm-2" id="basic-addon1">Nis</span>
                            <input name="nis" type="text" class="form-control" placeholder="Nis" aria-label="Username" aria-describedby="basic-addon1">
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text rounded-0 col-sm-2" id="basic-addon1">Nama</span>
                            <input name="nama" type="text" class="form-control" placeholder="Nama" aria-label="Username" aria-describedby="basic-addon1">
                        </div>
                        <div class="input-group mb-3">
                            <label class="input-group-text rounded-0 col-sm-2" for="inputGroupSelect01">Kelas</label>
                                <select name="id_kelas" class="form-select col-sm-10" id="inputGroupSelect01">
                                    <option selected hidden>Pilih Kelas...</option>
                                    <?php foreach ($GetKelas as $GetR) : ?>
                                        <option value="<?php echo $GetR->id_kelas; ?>"><?php echo $GetR->nama_kelas; ?></option>
                                    <?php endforeach; ?>
                                </select>
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text rounded-0 col-sm-2" id="basic-addon1">Alamat</span>
                            <input name="alamat" type="text" class="form-control" placeholder="Alamat" aria-label="Username" aria-describedby="basic-addon1">
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text rounded-0 col-sm-2" id="basic-addon1">No Teleponr</span>
                            <input name="no_telp" type="text" class="form-control" placeholder="No Telepon" aria-label="Username" aria-describedby="basic-addon1">
                        </div>
                        <div class="input-group mb-3">
                            <label class="input-group-text rounded-0 col-sm-2" for="inputGroupSelect01">Tahun Bayar</label>
                                <select name="id_spp" class="form-select col-sm-10" id="inputGroupSelect01">
                                    <option selected hidden>Pilih Tahun</option>
                                    <?php foreach ($GetSpp as $GetR) : ?>
                                        <option value="<?php echo $GetR->id_spp; ?>"><?php echo $GetR->tahun; ?></option>
                                    <?php endforeach; ?>

                                </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        
                      </form>
                      </div>
                      </div>
                  </div>
                  </div>
              </div>
            </div>


            <!-- END MAIN CONTENT-->
            <footer class="sticky-footer">
    <div class="container">
        <div class="copyright text-center">
            <span><?php echo SITE_NAME?></span>
        </div>
    </div>
</footer>
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    

</body>
<?php $this->load->view('admin/_partials/footer.php') ?>
<?php $this->load->view('admin/_partials/modal.php') ?>
</html>
<!-- end document-->
