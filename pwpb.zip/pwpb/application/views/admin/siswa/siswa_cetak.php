<!DOCTYPE html>
<html lang="en">

<head>
<?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body>
    <div class="text-center">
        <h2>LAPORAN PDF SISWA</h2>
    </div>
    <table class="table table-hover text-center"style="font-size: 10;">
                      <thead>
                        <tr class="text-primary">
                          <th scope="col" style="width:50px">No</th>
                          <th scope="col">NISN</th>
                          <th scope="col">NIS</th>
                          <th scope="col">Nama Lengkap</th>
                          <th scope="col">Kelas</th>
                          <th scope="col">Alamat</th>
                          <th scope="col">No Telepon</th>
                          <th scope="col">Tahun SPP</th>
                        </tr>
                      </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($sis as $sis) : ?>
                <tr>
                    <td>
                        <?php echo $no++; ?>
                    </td>
                    <td>
                        <?php echo $sis->nisn ?>
                    </td>
                    <td>
                        <?php echo $sis->nis ?>
                    </td>
                    <td>
                        <?php echo $sis->nama ?>
                    </td>
                    <td>
                        <?php echo $sis->nama_kelas ?>
                    </td>
                    <td>
                        <?php echo $sis->alamat ?>
                    </td>
                    <td>
                        <?php echo $sis->no_telp ?>
                    </td>
                    <td>
                        <?php echo $sis->tahun ?>
                    </td>

                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>

</html>