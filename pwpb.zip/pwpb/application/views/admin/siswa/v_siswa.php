<!DOCTYPE html>
<html lang="en">

<head>
<?php $this->load->view('admin/_partials/head.php') ?>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <?php $this->load->view('admin/_partials/header_mobile.php') ?>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <?php $this->load->view('admin/_partials/sidebar.php') ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php $this->load->view('admin/_partials/header_desktop.php') ?>
            <!-- HEADER DESKTOP-->

           <!-- MAIN CONTENT WRAPPER-->
           <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                    <?php $this->load->view('admin/_partials/breadcrump.php') ?>

                    <!-- ALERT CONTENT -->
                    <?php $this->load->view('admin/_partials/alert.php') ?>
                    
                    <!-- MAIN CONTENT -->


                  <div class="card border-info mb-5">
                      <div class="card-header d-flex justify-content-end">
                        <a class="btn btn-sm btn-outline-primary" href="<?php echo site_url('admin/siswa/add') ?>"><i class="fas fa-plus"> TAMBAH DATA</i></a>
                        <a class="btn btn-sm btn-outline-primary mx-1" href="<?php echo site_url('admin/siswa/cetak') ?>"><i class="fas fa-print"> CETAK DATA</i></a>
                      </div>
                    <table class="table table-hover text-center mb-5">
                      <thead>
                        <tr class="text-primary">
                          <th scope="col" style="width:50px">No</th>
                          <th scope="col">NISN</th>
                          <th scope="col">NIS</th>
                          <th scope="col">Nama Lengkap</th>
                          <th scope="col">Kelas</th>
                          <th scope="col">Alamat</th>
                          <th scope="col">No Telepon</th>
                          <th scope="col">Tahun SPP</th>
                          <th scope="col">Foto</th>
                          <th scope="col" style="width:100px">Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          if (!empty($GetSiswa)) {
                            $i = 1;
                          foreach ($GetSiswa as $GetR) {
                        ?>
                        <tr>
                          <td>
                            <?php
                              echo $i;
                              $i++;
                            ?>
                          </td>
                          <td><?php echo $GetR->nisn; ?></td>
                          <td><?php echo $GetR->nis; ?></td>
                          <td><?php echo $GetR->nama; ?></td>
                          <td><?php echo $GetR->nama_kelas; ?></td>
                          <td><?php echo $GetR->alamat; ?></td>
                          <td><?php echo $GetR->no_telp; ?></td>
                          <td><?php echo $GetR->tahun; ?></td>
                          <td><img src="<?php echo base_url('assets/img/') . $GetR->image; ?>" style="width:50px; height:40px;"></td>
                          <td class="text-center">
                            <a class="btn btn-sm btn-warning" href="<?php echo site_url('admin/siswa/edit/') . $GetR->nisn ?>">
                              <i class="fa fa-pen" aria-hidden="true"></i>
                            </a>
                            <a onclick="deleteConfirm('<?php echo site_url('admin/siswa/delete/' . $GetR->nisn) ?>')" href="#!" class="btn btn-sm btn-danger">
                              <i class="fas fa-trash"></i>
                            </a>
                          </td>

                        </tr>
                          <?php } } ?>
                      </tbody>
                    </table>
                      </div>
                      </div>
                  </div>
                  </div>
              </div>
            </div>


            <!-- END MAIN CONTENT-->
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    

</body>
<?php $this->load->view('admin/_partials/footer.php') ?>
<?php $this->load->view('admin/_partials/modal.php') ?>
</html>
<!-- end document-->
