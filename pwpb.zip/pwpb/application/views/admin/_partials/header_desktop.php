<header class="header-desktop border border-info">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">
                                <input class="au-input au-input--xl border border-info" type="text" name="search" placeholder="Cuma Pajangan" />
                                <button class="au-btn--submit border border-info" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                </button>
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">
                                    
                                </div>
                                <div class="account-wrap border border-info">
                                    <div class="account-item clearfix">
                                        <div class="image">
                                        <img src="<?php echo base_url('assets/img/') ?>default.jpg" />
                                        </div>
                                        <div class="noti-wrap">
                                            <a class="mx-1" data-toggle="modal" data-target="#exampleModal">LOGOUT<i class="fas fa-sign-out-alt mx-1"></i></a>
                                        </div>
                                 </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
            </header>


            <?php echo site_url('login/logout') ?>
            <!-- Model Logout -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Keluar</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Apa anda yakin untuk keluar
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Kembali</button>
        <a type="button" class="btn btn-danger" href="<?php echo site_url('login/logout') ?>">Keluar</a>
      </div>
    </div>
  </div>
</div>