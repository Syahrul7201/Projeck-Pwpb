<aside class="menu-sidebar d-none d-lg-block">
            <div class="logo border border-info">
                <a href="<?php echo site_url('admin') ?>">
                    <?php echo SITE_NAME ?>
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1 border border-info">
                <nav class="navbar-sidebar ">
                    <ul class="list-unstyled navbar__list ">
                        <?php if ($this->session->userdata('akses') == 'admin') : ?>
                        <li>
                            <a href="<?php echo site_url('admin/overview') ?>">
                                <i class="fas fa-home"></i>Beranda</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('admin/spp') ?>">
                            <i class="fas fa-money-check"></i>SPP</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('admin/kompetensi_keahlian') ?>">
                                <i class="fas fa-cog"></i>kompetensi_keahlian</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('admin/kelas') ?>">
                                <i class="fas fa-chart-area"></i>Kelas</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('admin/siswa') ?>">
                                <i class="fas fa-user"></i>Siswa</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('admin/petugas') ?>">
                                <i class="fas fa-user-shield"></i>Petugas</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('admin/pembayaran') ?>">
                                <i class="fas fa-history"></i>Transaksi Pembayaran</a>
                        </li>



                    <?php elseif ($this->session->userdata('akses') == 'petugas') : ?>
                        <li>
                            <a href="<?php echo site_url('admin/overview') ?>">
                                <i class="fas fa-home"></i>Beranda</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('admin/spp') ?>">
                            <i class="fas fa-money-check"></i>SPP</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('admin/siswa') ?>">
                                <i class="fas fa-user"></i>Siswa</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('admin/pembayaran') ?>">
                                <i class="fas fa-history"></i>Transaksi Pembayaran</a>
                        </li>
                        
                        
                    <?php else : ?>
                        <li>
                            <a href="<?php echo site_url('admin/overview') ?>">
                                <i class="fas fa-home"></i>Beranda</a>
                        </li>

                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </aside>